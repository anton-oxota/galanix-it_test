# Task 2

**npm i** - install dependencies  
**npm run dev** - run dev server  
**npm run build** - create build
